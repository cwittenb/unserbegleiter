repo: cwittenb/unserbegleiter
branch: main

## Last sync
date: 2026-07-25T12:32:07Z

### Updated in this project
- Turn 26: fünf Screens (S, VER, VGR, RVGR, ER) mit Titel im Wegweiser-Badge, Copy aus `core/i18n/de.js`.
- Regal geöffnet (RVGR): Naht wandert nach oben, Badge fährt mit der Kante.
- Offene Code-Folge: `weg.*` braucht einen Badge-Label-Schlüssel je Ort (Panel-Kopf bleibt `weg.badge`).

## Screen map
| Screen im Designdokument | Quelle im Repo |
| --- | --- |
| 26a Startseite (S) | core/i18n/de.js (start.hallo, start.capsMein/capsTeil, start.betreteMein/Teil, start.teilTitel, weg.badge) |
| 26b Vorraum eigener Raum (VER) | core/i18n/de.js (zone.raum, zone.regal, mein.solo, mein.einzelWeiter, mein.zeitleiste, mein.mess, mein.gruppeRegale) |
| 26c Vorraum gemeinsamer Raum (VGR) | core/i18n/de.js (teil.momentSub, teil.moment, teil.gemeinsam, teil.gateAufloesung, teil.regal, teil.agenda, teil.qz, teil.gruppeRegale) |
| 26d Regal geöffnet im VGR (RVGR) | core/i18n/de.js (regal.titel, regal.intro, regal.st*, regal.btn*), core/ui/app.js (regalTitel) |
| 26e Einzelraum (ER) | core/i18n/de.js (chat.raumVerlassen, chat.begleitung, chat.tippt, chat.platzhalter, chat.diktieren, chat.abschliessen) |
| 25a Vorraum für mich (Ist) | core/ui/app.js (rz-kopf-mitte), core/ui/design.js, core/i18n/de.js (start.capsMein, zone.raum, mein.*) |
| 25b Vorraum für mich (Lösung) | core/i18n/de.js (mein.soloSub, mein.einzelWeiter, mein.gruppeRegale, zone.*) |
| 25c Reflexionsgespräch + Freigabe | core/i18n/de.js (chat.*, gate.*) |
| 25d Wegweiser geöffnet | core/i18n/de.js (weg.badge, weg.startAuftrag, weg.startSolo, weg.optQz, weg.fuss) |
| Tokens/Bausteine (alle Turns) | core/ui/design.js, d13-kopfzeile-varianten.html (:root) |
| Handoff-Abgleich | varianteheaeder.md |
