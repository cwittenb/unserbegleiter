# Delta-Handover · Design Turn 27 → Code-Stand `cwittenb/unserbegleiter@main`

Nur die Punkte, die sich gegenüber dem heutigen Repo-Stand (`core/ui/app.js`, `core/ui/design.js`, `core/i18n/de.js`) geändert haben. Alles Übrige (Farben, Typo, Naht-Prinzip, Zonen, Kulisse) bleibt wie in `README.md` beschrieben.

Referenz: Turn **27** im Designdokument `Raumzuzweit Design.dc.html` — 27a Startseite · 27b Vorraum eigener Raum · 27c Vorraum gemeinsamer Raum · 27d Regal geöffnet · 27e Einzelraum.

---

## 1. Der Titel wandert in den Wegweiser

**Bisher:** `rz-kopf-mitte` trägt `start.capsMein` („Raum für mich") — direkt darüber/darunter steht der Serif-Titel `zone.raum`. Zwei Etiketten gleicher Ordnung.

**Neu:**
- Das Wegweiser-Badge auf der Naht trägt den **Ortsnamen**: „Raum für mich" / „Raum für uns".
- Die **Kopfzeile** trägt die Paar-Signatur „Christian & Lena" (11 px, 600, `letter-spacing:.34em`, uppercase, `#a3a894` bzw. `#8a9e7c`), zentriert.
- Nur auf der **Startseite** nennt sich der Wegweiser selbst: `weg.badge` („Wegweiser") — dort gibt es keinen einzelnen Ort.
- Im **geöffneten Panel** bleibt die Kopfzeile unverändert „Wegweiser" (`weg.badge`).

**i18n:** Badge-Label je Ort nötig. Wiederverwenden: `start.capsMein` / `start.capsTeil`; Auflösung im Wegweiser-Modul (`weg.*`) nach aktuellem Ort, Fallback `weg.badge`.

## 2. Ein Titel je Zone — `zone.regal` entfällt in den Vorräumen

Die Regalgruppe wird zum Zonentitel (Serif 26 px, 300, mit Punkt), die Caps-Gruppenzeile darüber entfällt ersatzlos:

| Zone | bisher | neu |
| --- | --- | --- |
| Vorraum eigener Raum, unten | H2 `zone.regal` + Caps `mein.gruppeRegale` | H2 **„Mein Weg."** (`mein.gruppeRegale`) |
| Vorraum gemeinsamer Raum, unten | H2 `zone.regal` + Caps `teil.gruppeRegale` | H2 **„Euer gemeinsamer Boden."** (`teil.gruppeRegale`) |

Oben bleibt `zone.raum` („Der Raum.") unverändert. `zone.regal` wird in den Vorräumen nicht mehr gerendert.

## 3. Wortmarke auf jedem Screen

„raumzuzweit" (11 px, 600, `.34em`, uppercase, zentriert) steht am **Fuß jedes Screens**, nicht nur auf der Startseite. Farbe: `#6f8062` auf Tiefgrün, `#a3a894` auf Papier. Abstand nach oben 28 px (Chat: 6 px unter der Abschluss-Zeile).

## 4. Das Regal ist ein Accordion, kein eigener Screen

- Aufgeklappt läuft das Regal **bis direkt unter die Kopfzeile**; sichtbar bleiben nur ← und die Paar-Signatur. „Der Raum.", seine Zeilen und der Zonentitel werden verdeckt.
- Die **Sektionsüberschrift bleibt die geklickte Zeile** — im gemeinsamen Raum also `teil.regal` („Geteiltes"), nicht „Das Regal.". Ihr Pfeil dreht auf **↑ = schließen**.
- Darunter `regal.titel` als Einleitungszeile, Einträge mit `regal.st*` / `regal.btn*`, am Fuß `regal.intro` als leise Erklärzeile.
- **Der Wegweiser fährt mit der Kante nach oben** und sitzt aufgeklappt unter der Kopfzeile — er blendet nicht um, er bewegt sich. Höhenwechsel ~300 ms, `cubic-bezier(.2,.8,.2,1)`.

## 5. Chat (Einzelraum)

- Rückweg im Kopf nur als Pfeil **←** statt des vollen `chat.raumVerlassen` — der Wortlaut passt neben der gesperrten Signatur nicht in 390 px.
- `chat.abschliessen` („Session abschließen") bekommt **←** statt ↑: ↑ heißt senden (in den Verlauf), ← heißt hinaus.
- Kein Screen-Titel im Kopf; der Ort steht im Badge.
- Das Freigabe-Blatt (`gate.*`) bleibt unverändert ein Overlay über der Schreibkante.

---

## Was das im Code betrifft

- `core/ui/app.js`: Inhalt von `rz-kopf-mitte` (Paar-Signatur statt Raum-Caps) · Badge-Label-Quelle · Vorraum-Zonen: H2 unten aus der Regalgruppe, Caps-Zeile entfernen · Marke als Fußzeile in jeden Screen-Rahmen · Regal-Zeilen im gemeinsamen Raum als Accordion (Höhe der oberen Hälfte animiert, Badge an der Kante verankert).
- `core/ui/design.js`: `.rz-caps` in der Kopfzeile auf `letter-spacing:.34em`; Fußzeilen-Marke als eigene Klasse; Transition für die Zonenhöhe.
- `core/i18n/de.js`: keine neuen Texte nötig außer der Zuordnung Badge → Ort. `zone.regal` bleibt im Wörterbuch (Verwendung entfällt nur in den Vorräumen).
